                <?php

                include('srms.php');

				$object = new srms();

				if(!$object->is_login())
				{
				    header("location:".$object->base_url."");
				}

                if(!$object->is_master_user())
                {
                    header("location:".$object->base_url."admin/result.php");
                }

                include('header.php');

                ?>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>

                    <!-- Content Row -->
                    <div class="row row-cols-5">
                        <?php
                        if($object->is_master_user())
                        {
                        ?>
                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Today Result Publish</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $object->Get_total_result(); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Total Exam</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $object->Get_total_exam(); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Student
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $object->Get_total_student(); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Total Subject</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $object->Get_total_subject();?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>     
                        <div class="col mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Total Classes</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $object->Get_total_classes();?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>                  

                    <?php
                    }
                    ?>
                    </div>


                    <?php
/**
 * Charts 4 PHP
 *
 * @author Shani <support@chartphp.com> - http://www.chartphp.com
 * @version 2.0
 * @license: see license.txt included in package
 */

include_once("srms.php");
include_once(CHARTPHP_LIB_PATH . "/inc/chartphp_dist.php");

$p = new chartphp();

$p->data_sql = "select strftime('%Y-%m',o.orderdate) as Year, sum(d.quantity) as 'Sales 1996', sum(d.quantity)+1000 as 'Sales 1997', sum(d.quantity)+2000 as 'Sales 1998'
                    from `order details` d, orders o
                    where o.orderid = d.orderid
                    group by strftime('%Y-%m',o.orderdate) limit 50";

$p->chart_type = "line";

// Common Options
$p->title = "Sales Summary";
$p->xlabel = "Month";
$p->ylabel = "Sales";
// $p->shape = "linear";
// $p->show_point_label = true;

$out = $p->render('c1');
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../../lib/js/chartphp.css">
        <script src="../../lib/js/jquery.min.js"></script>
        <script src="../../lib/js/chartphp.js"></script>
    </head>
    <body>
        <div>
            <?php echo $out; ?>
        </div>
    </body>
</html>


                    

                <?php
                include('footer.php');
                ?>  